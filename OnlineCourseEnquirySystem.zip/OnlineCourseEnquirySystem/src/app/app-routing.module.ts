import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainModule } from './main/main.module';
import { InformationModule } from './information/information.module';
import { CoursesModule } from './courses/courses.module';

import { HomeComponent } from './main/home/home.component';
import { AboutComponent } from './main/about/about.component';
import { ContactComponent } from './main/contact/contact.component';
import { CourseListComponent } from './courses/course-list/course-list.component';
import { FaqsComponent } from './information/faqs/faqs.component';
import { HelpComponent } from './information/help/help.component';
import { RepresentativeComponent } from './authentication/representative/representative.component';
import { AdminComponent } from './authentication/admin/admin.component';
import { AuthenticationModule } from './authentication/authentication.module';
import { LoginComponent } from './authentication/login/login.component';
import { ManageCoursesComponent } from './courses/manage-courses/manage-courses.component';
import { ManageUsersComponent } from './authentication/manage-users/manage-users.component';

const routes: Routes = [
  { path:"", pathMatch:"full", redirectTo:"home" },
  {path:"home", component:HomeComponent},
  {path:"about", component:AboutComponent},
  {path:"contact", component:ContactComponent},
  {path:"login", component:LoginComponent},
  {path:"courses", component:CourseListComponent},
  {path:"manageCourses", component:ManageCoursesComponent},
  {path:"manageUsers", component:ManageUsersComponent},
  {path:"faqs", component:FaqsComponent},
  {path:"help", component:HelpComponent},
  {path:"representative", component:RepresentativeComponent},
  {path:"admin", component:AdminComponent}
];

@NgModule({

  imports: [
    RouterModule.forRoot(routes),
    MainModule,
    AuthenticationModule,
    InformationModule,
    CoursesModule
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
