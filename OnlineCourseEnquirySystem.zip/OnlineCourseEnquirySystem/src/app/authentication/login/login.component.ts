import { Component, OnInit, Output } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  message:string="";
  usrName:string;

  constructor(private service:UserService, private router:Router) { }

  ngOnInit() {
  }

  authenticate(user)
  {
    this.service.signIn(user).then(response=>{
      this.usrName=response['name'];
      sessionStorage.setItem("loggedInUser",this.usrName);
      if(response['role']=='ADMIN')
      {
        this.router.navigate(['/admin']).then(()=>{
          window.location.reload();
        });
      }
      else if(response['role']=='REPRESENTATIVE')
      {
        this.router.navigate(['/representative']).then(()=>{
          window.location.reload();
        });
      }
      else
      {
        this.message="Invalid Email or Password!!!";
      }
    }).catch(error=>{
      console.log(error);
      this.message="Oops!! Something went wrong";
    });
  }

}
