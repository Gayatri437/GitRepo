import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  loggedInUser:string=null;

  constructor() { }

  ngOnInit() {
    this.loggedInUser=sessionStorage.getItem("loggedInUser");
    console.log(this.loggedInUser);

    if(this.loggedInUser == '')
    {
      this.loggedInUser=null;
    }
  }

}
