import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-representative',
  templateUrl: './representative.component.html',
  styleUrls: ['./representative.component.css']
})
export class RepresentativeComponent implements OnInit {

  repName:string;

  constructor(private router:Router, private activateRoute:ActivatedRoute) { }

  ngOnInit() {
    this.repName=sessionStorage.getItem("loggedInUser");
  }

  logout()
  {
    sessionStorage.removeItem("loggedInUser");
    this.router.navigate(["/home"]).then(()=>{
      window.location.reload();
    })
  }

}
