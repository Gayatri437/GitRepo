import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent implements OnInit {
  public isViewable: boolean;
  constructor() { }

  ngOnInit() {
  }

  public toggle(): void { this.isViewable = !this.isViewable; }
}

