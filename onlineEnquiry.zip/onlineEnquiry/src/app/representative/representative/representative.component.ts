import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-representative',
  templateUrl: './representative.component.html',
  styleUrls: ['./representative.component.css']
})
export class RepresentativeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
