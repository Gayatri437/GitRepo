import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RepresentativeComponent } from './representative/representative.component';



@NgModule({
  declarations: [RepresentativeComponent],
  imports: [
    CommonModule
  ]
})
export class RepresentativeModule { }
