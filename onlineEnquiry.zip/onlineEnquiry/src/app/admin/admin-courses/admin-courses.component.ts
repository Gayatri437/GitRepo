import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-courses',
  templateUrl: './admin-courses.component.html',
  styleUrls: ['./admin-courses.component.css']
})
export class AdminCoursesComponent implements OnInit {

  public show:boolean = false;
  public buttonName:any = 'Show Details Of the Course';

  constructor() { }

  ngOnInit() {
  }

  toggle() {
    this.show = !this.show;

    // CHANGE THE NAME OF THE BUTTON.
    if(this.show)  
      this.buttonName = "Hide Details of the Course";
    else
      this.buttonName = "Show Details of the Course";
  }
}
