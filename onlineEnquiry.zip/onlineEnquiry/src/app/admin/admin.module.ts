import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminComponent } from './admin/admin.component';
import { AdminCoursesComponent } from './admin-courses/admin-courses.component';
import { AdminResponsesComponent } from './admin-responses/admin-responses.component';



@NgModule({
  declarations: [AdminComponent, AdminCoursesComponent, AdminResponsesComponent],
  imports: [
    CommonModule
  ]
})
export class AdminModule { }
