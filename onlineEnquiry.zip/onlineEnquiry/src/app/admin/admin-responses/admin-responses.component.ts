import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-responses',
  templateUrl: './admin-responses.component.html',
  styleUrls: ['./admin-responses.component.css']
})
export class AdminResponsesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
